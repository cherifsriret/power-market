<?php
return [
'reset'=>'إلغاء',
'submit'=>'حفظ',
'created_at'=>'تاريخ الاضافة',
'actions'=>'أجراءات',
's_n'=>'رقم',
'delete'=>'حذف',
'are_you_sure'=>'هل أنت متأكد؟',
'msg_confirm_delete'=>'! بمجرد الحذف ، لن تتمكن من استعادة هذه البيانات',
'your_data_safe'=>'! بياناتك آمنة',
'print'=>'طباعة',
'status'=>'الحالة',
'enter_status'=>'اختر الحالة',
'status_active'=>'مفعل',
'status_inactive'=>'غير مفعل',

];
