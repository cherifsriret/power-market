<?php
return [
'invitation'=>'دعوة',
'invitations'=>'الدعوات',
'visitor_name'=>'اسم الزائر',
'enter_visitor_name'=>'أدخل اسم الزائر',
'visit_type'=>'نوع الدعوة',
'select_type'=>'اختر نوع الدعوة',
'single_visit'=>'زيارة واحدة',
'multiple_visit'=>'زيارة متعددة',
'visit_from_time'=>'وقت الزيارة من',
'enter_visit_from_time'=>'أدخل وقت بدء الزيارة',
'visit_to_time'=>'وقت الزيارة الي',
'enter_visit_to_time'=>'أدخل وقت انتهاء الزيارة',
'visit_from_date'=>'تاريخ الزيارة من',
'enter_visit_from_date'=>'أدخل تاريخ بدء الزيارة',
'visit_to_date'=>'تاريخ الزيارة الي',
'enter_visit_to_date'=>'أدخل تاريخ انتهاء الزيارة',
'success_added'=>'تمت إضافة الدعوة بنجاح',
'error_added'=>'حدث خطأ أثناء إضافة الدعوة',
'add_invitation'=>'أضافة دعوة',
'list_invitations'=>'قائمة الدعوات',
'all_invitations'=>'كل الدعوات',
'our_invitations'=>'الدعوات الخاصة بي',
'invitation_options'=>'خيارات الدعوات',
'owner'=>'صاحب الدعوة',
'success_delete'=>'تم حذف الدعوة بنجاح',
'error_delete'=>'حدث خطأ أثناء حذف الدعوة',
'update_invitation'=>'تحديث الدعوة',
'success_update'=>'م تحديث الدعوة بنجاح',
'error_update'=>'حدث خطأ أثناء تحديث الدعوة',
'show_invitation'=>'عرض الدعوة',




];
