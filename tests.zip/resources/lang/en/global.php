<?php
return [
'reset'=>'Reset',
'submit'=>'Submit',
'created_at'=>'Created at',
'actions'=>'Actions',
's_n'=>'S.N',
'delete'=>'Delete',
'are_you_sure'=>'Are you sure?',
'msg_confirm_delete'=>'Once deleted, you will not be able to recover this data!',
'your_data_safe'=>'Your data is safe!',
'print'=>'Print',
'status'=>'Status',
'enter_status'=>'Select Status',
'status_active'=>'Active',
'status_inactive'=>'Inactive',

];
