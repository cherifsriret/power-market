<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Custom Validation Attributes
|--------------------------------------------------------------------------
|
| The following language lines are used to swap our attribute placeholder
| with something more reader friendly such as "E-Mail Address" instead
| of "email". This simply helps us make our message more expressive.
|
*/

return [
    'attributes' => [
        'address'               => 'Address',
        'age'                   => 'Age',
        'body'                  => 'Body',
        'city'                  => 'City',
        'content'               => 'Content',
        'country'               => 'Country',
        'date'                  => 'Date',
        'day'                   => 'Day',
        'description'           => 'Description',
        'email'                 => 'Email',
        'excerpt'               => 'Excerpt',
        'first_name'            => 'First Name',
        'gender'                => 'Gender',
        'hour'                  => 'Hour',
        'last_name'             => 'Last Name',
        'message'               => 'Message',
        'minute'                => 'Minute',
        'mobile'                => 'Mobile',
        'month'                 => 'Month',
        'name'                  => 'Name',
        'password'              => 'Password',
        'password_confirmation' => 'Password Confirmation',
        'phone'                 => 'Phone',
        'photo'                 => 'Photo',
        'price'                 => 'Price',
        'role'                  => 'Role',
        'second'                => 'Second',
        'sex'                   => 'Sex',
        'subject'               => 'Subject',
        'terms'                 => 'Terms',
        'time'                  => 'Time',
        'title'                 => 'Title',
        'username'              => 'Username',
        'year'                  => 'Year',
    ],
];
